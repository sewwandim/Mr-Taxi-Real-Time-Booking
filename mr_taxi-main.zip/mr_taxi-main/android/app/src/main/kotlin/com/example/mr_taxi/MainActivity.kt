package com.example.mr_taxi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
